//
//  EleetEthereumWallet.h
//  EleetEthereumWallet
//
//  Created by Ельнар Шопанов on 27.06.2018.
//  Copyright © 2018 руслан. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EleetEthereumWallet.
FOUNDATION_EXPORT double EleetEthereumWalletVersionNumber;

//! Project version string for EleetEthereumWallet.
FOUNDATION_EXPORT const unsigned char EleetEthereumWalletVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EleetEthereumWallet/PublicHeader.h>


