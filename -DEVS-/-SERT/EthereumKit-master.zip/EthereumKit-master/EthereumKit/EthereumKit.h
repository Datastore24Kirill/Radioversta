#import <UIKit/UIKit.h>

//! Project version number for EthereumKit.
FOUNDATION_EXPORT double EthereumKitVersionNumber;

//! Project version string for EthereumKit.
FOUNDATION_EXPORT const unsigned char EthereumKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EthereumKit/PublicHeader.h>


